/*
 * Copyright (c) 2018 Martin Denham, Tuomas Airaksinen and the And Bible contributors.
 *
 * This file is part of And Bible (http://github.com/AndBible/and-bible).
 *
 * And Bible is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * And Bible is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with And Bible.
 * If not, see http://www.gnu.org/licenses/.
 *
 */

package net.bibliavariasversiones.android.view.activity;

import net.bibliavariasversiones.android.activity.SpeakWidgetManager;
import net.bibliavariasversiones.android.control.ApplicationComponent;
import net.bibliavariasversiones.android.view.activity.base.ActivityBase;
import net.bibliavariasversiones.android.view.activity.bookmark.BookmarkLabels;
import net.bibliavariasversiones.android.view.activity.bookmark.Bookmarks;
import net.bibliavariasversiones.android.view.activity.bookmark.ManageLabels;
import net.bibliavariasversiones.android.view.activity.comparetranslations.CompareTranslations;
import net.bibliavariasversiones.android.view.activity.download.Download;
import net.bibliavariasversiones.android.view.activity.download.ProgressStatus;
import net.bibliavariasversiones.android.view.activity.footnoteandref.FootnoteAndRefActivity;
import net.bibliavariasversiones.android.view.activity.mynote.MyNotes;
import net.bibliavariasversiones.android.view.activity.navigation.ChooseDictionaryWord;
import net.bibliavariasversiones.android.view.activity.navigation.ChooseDocument;
import net.bibliavariasversiones.android.view.activity.navigation.GridChoosePassageBook;
import net.bibliavariasversiones.android.view.activity.navigation.GridChoosePassageChapter;
import net.bibliavariasversiones.android.view.activity.navigation.GridChoosePassageVerse;
import net.bibliavariasversiones.android.view.activity.navigation.History;
import net.bibliavariasversiones.android.view.activity.navigation.genbookmap.ChooseKeyBase;
import net.bibliavariasversiones.android.view.activity.readingplan.DailyReading;
import net.bibliavariasversiones.android.view.activity.readingplan.DailyReadingList;
import net.bibliavariasversiones.android.view.activity.readingplan.ReadingPlanSelectorList;
import net.bibliavariasversiones.android.view.activity.search.Search;
import net.bibliavariasversiones.android.view.activity.search.SearchIndex;
import net.bibliavariasversiones.android.view.activity.search.SearchIndexProgressStatus;
import net.bibliavariasversiones.android.view.activity.search.SearchResults;
import net.bibliavariasversiones.android.view.activity.speak.GeneralSpeakActivity;
import net.bibliavariasversiones.android.view.activity.speak.BibleSpeakActivity;

import dagger.Component;

import net.bibliavariasversiones.android.view.activity.speak.SpeakSettingsActivity;
import net.bibliavariasversiones.android.view.util.widget.SpeakTransportWidget;
import net.bibliavariasversiones.servicios.device.speak.TextToSpeechNotificationManager;

/**
 * Dagger Component to allow injection of dependencies into activities.
 *
 * @author Martin Denham [mjdenham at gmail dot com]
 */
@ActivityScope
@Component(dependencies = {ApplicationComponent.class} )
public interface ActivityComponent {
	// Activities that are permitted to be injected

	// don't like this but inject is called from ActivityBase and the subclasses
	void inject(ActivityBase activityBase);

	void inject(StartupActivity startupActivity);

	void inject(Bookmarks bookmarks);
	void inject(BookmarkLabels bookmarkLabels);
	void inject(ManageLabels manageLabels);

	void inject(GridChoosePassageBook gridChoosePassageBook);
	void inject(GridChoosePassageChapter gridChoosePassageChapter);
	void inject(GridChoosePassageVerse gridChoosePassageVerse);
	void inject(ChooseDictionaryWord chooseDictionaryWord);
	void inject(ChooseKeyBase chooseKeyBase);

	void inject(ChooseDocument chooseDocument);
	void inject(Download download);

	void inject(GeneralSpeakActivity speak);
	void inject(BibleSpeakActivity speakBible);
	void inject(SpeakSettingsActivity speakSettings);
	void inject(DailyReading dailyReading);
	void inject(DailyReadingList dailyReadingList);
	void inject(ReadingPlanSelectorList readingPlanSelectorList);
	void inject(SearchIndex searchIndex);
	void inject(SpeakTransportWidget w);
	void inject(Search search);
	void inject(SearchResults searchResults);
	void inject(CompareTranslations compareTranslations);
	void inject(FootnoteAndRefActivity footnoteAndRefActivity);
	void inject(MyNotes myNotes);
	void inject(History history);

	// Services
	void inject(TextToSpeechNotificationManager m);
	void inject(SpeakWidgetManager w);

	// progress status screens
	void inject(SearchIndexProgressStatus searchIndexProgressStatus);
	void inject(ProgressStatus progressStatus);
}
