/*
 * Copyright (c) 2018 Martin Denham, Tuomas Airaksinen and the And Bible contributors.
 *
 * This file is part of And Bible (http://github.com/AndBible/and-bible).
 *
 * And Bible is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * And Bible is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with And Bible.
 * If not, see http://www.gnu.org/licenses/.
 *
 */

package net.bibliavariasversiones.android.view.activity.page

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.view.menu.MenuBuilder
import androidx.appcompat.view.menu.MenuPopupHelper
import net.bibliavariasversiones.android.BibleApplication
import net.bibliavariasversiones.android.activity.EscucharBiblia
import net.bibliavariasversiones.android.activity.R
import net.bibliavariasversiones.android.activity.SplashVersiculos
import net.bibliavariasversiones.android.control.backup.BackupControl
import net.bibliavariasversiones.android.control.download.DownloadControl
import net.bibliavariasversiones.android.control.page.window.ActiveWindowPageManagerProvider
import net.bibliavariasversiones.android.control.page.window.WindowControl
import net.bibliavariasversiones.android.control.readingplan.ReadingPlanControl
import net.bibliavariasversiones.android.control.search.SearchControl
import net.bibliavariasversiones.android.view.activity.MainBibleActivityScope
import net.bibliavariasversiones.android.view.activity.base.ActivityBase
import net.bibliavariasversiones.android.view.activity.base.IntentHelper
import net.bibliavariasversiones.android.view.activity.bookmark.Bookmarks
import net.bibliavariasversiones.android.view.activity.bookmark.ManageLabels
import net.bibliavariasversiones.android.view.activity.download.Download
import net.bibliavariasversiones.android.view.activity.installzip.InstallZip
import net.bibliavariasversiones.android.view.activity.mynote.MyNotes
import net.bibliavariasversiones.android.view.activity.navigation.ChooseDocument
import net.bibliavariasversiones.android.view.activity.navigation.GridChoosePassageBook
import net.bibliavariasversiones.android.view.activity.navigation.History
import net.bibliavariasversiones.android.view.activity.page.MainBibleActivity.Companion.BACKUP_RESTORE_REQUEST
import net.bibliavariasversiones.android.view.activity.page.MainBibleActivity.Companion.BACKUP_SAVE_REQUEST
import net.bibliavariasversiones.android.view.activity.page.screen.WindowMenuCommandHandler
import net.bibliavariasversiones.android.view.activity.readingplan.DailyReading
import net.bibliavariasversiones.android.view.activity.readingplan.ReadingPlanSelectorList
import net.bibliavariasversiones.android.view.activity.settings.SettingsActivity
import net.bibliavariasversiones.android.view.activity.speak.GeneralSpeakActivity
import net.bibliavariasversiones.android.view.activity.speak.BibleSpeakActivity
import net.bibliavariasversiones.servicios.common.CommonUtils
import org.crosswire.jsword.book.BookCategory

import javax.inject.Inject

/** Handle requests from the main menu
 *
 * @author Martin Denham [mjdenham at gmail dot com]
 */
@MainBibleActivityScope
class MenuCommandHandler @Inject
constructor(private val callingActivity: MainBibleActivity,
            private val readingPlanControl: ReadingPlanControl,
            private val searchControl: SearchControl,
            private val windowMenuCommandHandler: WindowMenuCommandHandler,
            private val activeWindowPageManagerProvider: ActiveWindowPageManagerProvider,
            private val windowControl: WindowControl,
            private val downloadControl: DownloadControl,
            private val backupControl: BackupControl
) {

    /**
     * on Click handlers
     */
    @SuppressLint("RestrictedApi")
    fun handleMenuRequest(menuItem: MenuItem): Boolean {
        var isHandled = false

        // Activities
        run {
            var handlerIntent: Intent? = null
            var requestCode = ActivityBase.STD_REQUEST_CODE
            // Handle item selection
            when (menuItem.itemId) {
                R.id.chooseDocumentButton -> {
                    val intent = Intent(callingActivity, ChooseDocument::class.java)
                    callingActivity.startActivityForResult(intent, ActivityBase.STD_REQUEST_CODE)
                }
                R.id.LibrosDelaBiblia -> {
                    val intent = Intent(callingActivity, GridChoosePassageBook::class.java)
                    callingActivity.startActivityForResult(intent, ActivityBase.STD_REQUEST_CODE)
                }

                R.id.VersiculoDel -> {
                    val intent = Intent(callingActivity, SplashVersiculos::class.java)
                    callingActivity.startActivityForResult(intent, ActivityBase.STD_REQUEST_CODE)
                }
                R.id.escuchar -> {
                    val intent = Intent(callingActivity, EscucharBiblia::class.java)
                    callingActivity.startActivityForResult(intent, ActivityBase.STD_REQUEST_CODE)
                }

                R.id.rateButton -> {
                    val uri = Uri.parse("market://details?id=" + callingActivity.packageName)
                    val intent = Intent(Intent.ACTION_VIEW, uri).apply{
                        // To count with Play market backstack, After pressing back button,
                        // to taken back to our application, we need to add following flags to intent.
                        addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
                        }
                    }
                    try {
                        callingActivity.startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        val httpUri = Uri.parse("https://play.google.com/store/apps/details?id=" + callingActivity.packageName)
                        callingActivity.startActivity(Intent(Intent.ACTION_VIEW, httpUri))
                    }
                }
                R.id.backupMainMenu -> {
                    val view: View = callingActivity.findViewById(R.id.homeButton)
                    val menu = PopupMenu(callingActivity, view).apply {
                        menuInflater.inflate(R.menu.backup_submenu, menu)
                        setOnMenuItemClickListener {handleMenuRequest(it)}
                    }

                    val menuHelper = MenuPopupHelper(callingActivity, menu.menu as MenuBuilder, view)
                    menuHelper.setForceShowIcon(true)
                    menuHelper.show()
                }
                R.id.searchButton -> handlerIntent = searchControl.getSearchIntent(activeWindowPageManagerProvider.activeWindowPageManager.currentPage.currentDocument)
                R.id.settingsButton -> {
                    handlerIntent = Intent(callingActivity, SettingsActivity::class.java)
                    // force the bibliavariasversiones view to be refreshed after returning from settings screen because notes, verses, etc. may be switched on or off
                    requestCode = IntentHelper.REFRESH_DISPLAY_ON_FINISH
                }
                R.id.historyButton -> handlerIntent = Intent(callingActivity, History::class.java)
                R.id.bookmarksButton -> handlerIntent = Intent(callingActivity, Bookmarks::class.java)
                R.id.manageLabels -> {
                    handlerIntent = Intent(callingActivity, ManageLabels::class.java)
                    requestCode = IntentHelper.REFRESH_DISPLAY_ON_FINISH
                }
                R.id.mynotesButton -> handlerIntent = Intent(callingActivity, MyNotes::class.java)
                R.id.speakButton -> {
                    val isBible = windowControl.activeWindowPageManager.currentPage
                            .bookCategory == BookCategory.BIBLE
                    handlerIntent = Intent(callingActivity, if (isBible) BibleSpeakActivity::class.java else GeneralSpeakActivity::class.java)
                }
                R.id.dailyReadingPlanButton ->
                    // show todays plan or allow plan selection
                    handlerIntent = if (readingPlanControl.isReadingPlanSelected) {
                        Intent(callingActivity, DailyReading::class.java)
                    } else {
                        Intent(callingActivity, ReadingPlanSelectorList::class.java)
                    }
                R.id.downloadButton -> if (downloadControl.checkDownloadOkay()) {
                    handlerIntent = Intent(callingActivity, Download::class.java)
                    requestCode = IntentHelper.UPDATE_SUGGESTED_DOCUMENTS_ON_FINISH
                }
                R.id.installZipButton -> handlerIntent = Intent(callingActivity, InstallZip::class.java)
                R.id.helpButton -> {
                    val httpUri = Uri.parse("https://app.bibliagrafica.com/privacy.html")
                    callingActivity.startActivity(Intent(Intent.ACTION_VIEW, httpUri))
                }
                R.id.Rvl1960 -> {
                    val httpUri = Uri.parse("market://details?id=biblia.reina.v1960")
                    callingActivity.startActivity(Intent(Intent.ACTION_VIEW, httpUri))
                }
                R.id.backup -> {
                    if (ContextCompat.checkSelfPermission(callingActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        ActivityCompat.requestPermissions(callingActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), BACKUP_SAVE_REQUEST)
                    } else {
                        backupControl.backupDatabase()
                    }
                    isHandled = true
                }
                R.id.restore -> {
                    if (ContextCompat.checkSelfPermission(callingActivity, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        ActivityCompat.requestPermissions(callingActivity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), BACKUP_RESTORE_REQUEST)
                    } else {
                        backupControl.restoreDatabase()
                    }
                    isHandled = true
                }
            }//handlerIntent = new Intent(callingActivity, Help.class);

            if (!isHandled) {
                isHandled = windowMenuCommandHandler.handleMenuRequest(menuItem)
            }

            if (handlerIntent != null) {
                callingActivity.startActivityForResult(handlerIntent, requestCode)
                isHandled = true
            }
        }

        return isHandled
    }

    fun restartIfRequiredOnReturn(requestCode: Int): Boolean {
        if (requestCode == IntentHelper.REFRESH_DISPLAY_ON_FINISH) {
            Log.i(TAG, "Refresh on finish")
            if (!equals(CommonUtils.getLocalePref()?: "", BibleApplication.application.localeOverrideAtStartUp)) {
                // must restart to change locale
                CommonUtils.restartApp(callingActivity)
            }
        }
        return false
    }

    fun isDisplayRefreshRequired(requestCode: Int): Boolean {
        return requestCode == IntentHelper.REFRESH_DISPLAY_ON_FINISH
    }

    fun isDocumentChanged(requestCode: Int): Boolean {
        return requestCode == IntentHelper.UPDATE_SUGGESTED_DOCUMENTS_ON_FINISH
    }

    companion object {

        private const val TAG = "MainMenuCommandHandler"

        internal fun equals(a: String?, b: String?): Boolean {
            return a === b || (a != null && a == b)
        }
    }
}
