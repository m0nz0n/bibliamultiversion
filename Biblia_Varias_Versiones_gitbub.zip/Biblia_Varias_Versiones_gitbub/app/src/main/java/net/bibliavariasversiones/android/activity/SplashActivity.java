package net.bibliavariasversiones.android.activity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;


import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {
	private static final int WAIT_TIME = 4000;
	private InterstitialAd interstitial;
	private Timer waitTimer;
	private boolean interstitialCanceled = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		MobileAds.initialize(this, getString(R.string.admob_id_aplicacion));
		interstitial = new InterstitialAd(this);
		interstitial.setAdUnitId(getString(R.string.interstitial_publicidad));
		interstitial.setAdListener(new AdListener() {
			@Override
			public void onAdLoaded() {
				if (!interstitialCanceled) {
					interstitial.show();
				}
			}
			@Override
			public void onAdFailedToLoad(int errorCode) {
				startMainActivity();
			}
			@Override
			public void onAdClosed() {
				startMainActivity();
			}
		});
		interstitial.loadAd(new AdRequest.Builder().build());
		waitTimer = new Timer();
		waitTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				interstitialCanceled = true;
				SplashActivity.this.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						startMainActivity();
					}
				});
			}
		}, WAIT_TIME);
	}
	@Override
	public void onPause() {
		waitTimer.cancel();
		interstitialCanceled = true;
		super.onPause();
	}
	@Override
	public void onResume() {
		super.onResume();
		if (interstitial.isLoaded()) {
			interstitial.show();
		} else if (interstitialCanceled) {
			startMainActivity();
		}
	}
	private void startMainActivity() {
		if (getIntent().hasExtra("versiculo")){
			startActivity(new Intent(SplashActivity.this, VersiculoDeldia.class));
			finish();
		} else  {
			if (getIntent().hasExtra("url")){
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://app.bibliagrafica.com/enviar")));
			} else {
				if (getIntent().hasExtra("audio")){
					startActivity(new Intent(SplashActivity.this, EscucharBiblia.class));
					finish();
				} else {
					startActivity(new Intent(SplashActivity.this, StartupActivity.class));
					finish();
				}
			}
		}
	}
}


