/*
 * Copyright (c) 2018 Martin Denham, Tuomas Airaksinen and the And Bible contributors.
 *
 * This file is part of And Bible (http://github.com/AndBible/and-bible).
 *
 * And Bible is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * And Bible is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with And Bible.
 * If not, see http://www.gnu.org/licenses/.
 *
 */

package net.bibliavariasversiones.android.view.activity.mynote

import android.graphics.Color
import androidx.appcompat.widget.AppCompatEditText
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

import net.bibliavariasversiones.android.control.event.ABEventBus
import net.bibliavariasversiones.android.control.event.apptobackground.AppToBackgroundEvent
import net.bibliavariasversiones.android.control.event.passage.BeforeCurrentPageChangeEvent
import net.bibliavariasversiones.android.control.mynote.MyNoteControl
import net.bibliavariasversiones.android.control.page.ChapterVerse
import net.bibliavariasversiones.android.view.activity.base.DocumentView
import net.bibliavariasversiones.android.view.activity.page.MainBibleActivity
import net.bibliavariasversiones.servicios.common.CommonUtils
import net.bibliavariasversiones.servicios.device.ScreenSettings


/**
 * Show a User Note and allow view/edit
 *
 * @author Martin Denham [mjdenham at gmail dot com]
 */
class MyNoteEditTextView(private val mainBibleActivity: MainBibleActivity, private val myNoteControl: MyNoteControl) :
		AppCompatEditText(mainBibleActivity), DocumentView {

    init {

        setSingleLine(false)
        val layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        )
        setLayoutParams(layoutParams)
        gravity = Gravity.TOP
        isVerticalScrollBarEnabled = true
        updatePadding()
        applyPreferenceSettings()
    }

    private fun updatePadding() {
        setPadding(mainBibleActivity.leftOffset1.toInt(),
                mainBibleActivity.topOffsetWithActionBar.toInt(),
                mainBibleActivity.rightOffset1.toInt(),
                mainBibleActivity.bottomOffset2.toInt())
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        // register for passage change events
        ABEventBus.getDefault().register(this)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()

        // register for passage change events
        ABEventBus.getDefault().unregister(this)
    }

    /** allow current page to save any settings or data before being changed
     */
    fun onEvent(event: BeforeCurrentPageChangeEvent) {
        // force MyNote.save if in MyNote and suddenly change to another view
        save()
    }

	fun onEvent(event: AppToBackgroundEvent) {
		save()
	}

    private fun save() {
        myNoteControl.saveMyNoteText(text!!.toString())
    }

    override fun show(html: String, chapterVerse: ChapterVerse, jumpToYOffsetRatio: Float) {
        applyPreferenceSettings()
        setText(html)
        updatePadding()
    }

    override fun applyPreferenceSettings() {
        changeBackgroundColour()

        val preferences = CommonUtils.getSharedPreferences()
        val fontSize = preferences.getInt("text_size_pref", 16)
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, fontSize.toFloat())
    }

    override fun changeBackgroundColour() {
        if (ScreenSettings.isNightMode) {
            setBackgroundColor(Color.BLACK)
            setTextColor(Color.WHITE)
        } else {
            setBackgroundColor(Color.WHITE)
            setTextColor(Color.BLACK)
        }
    }

    override fun isPageNextOkay(): Boolean {
        return false
    }

    override fun isPagePreviousOkay(): Boolean {
        return false
    }

    override fun pageDown(toBottom: Boolean): Boolean {
        return false
    }

    override fun getCurrentPosition(): Float {
        return 0f
    }

    override fun asView(): View {
        return this
    }

    override fun onScreenTurnedOn() {
        // NOOP
    }

    override fun onScreenTurnedOff() {
        // NOOP
    }

    companion object {

        private val TAG = "MyNoteEditTextView"
    }
}
