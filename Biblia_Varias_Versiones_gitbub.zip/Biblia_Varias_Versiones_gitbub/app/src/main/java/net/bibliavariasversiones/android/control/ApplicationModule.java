/*
 * Copyright (c) 2018 Martin Denham, Tuomas Airaksinen and the And Bible contributors.
 *
 * This file is part of And Bible (http://github.com/AndBible/and-bible).
 *
 * And Bible is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * And Bible is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with And Bible.
 * If not, see http://www.gnu.org/licenses/.
 *
 */

package net.bibliavariasversiones.android.control;

import net.bibliavariasversiones.android.common.resource.AndroidResourceProvider;
import net.bibliavariasversiones.android.common.resource.ResourceProvider;
import net.bibliavariasversiones.android.control.download.DownloadControl;
import net.bibliavariasversiones.android.control.download.DownloadQueue;
import net.bibliavariasversiones.android.control.email.Emailer;
import net.bibliavariasversiones.android.control.email.EmailerImpl;
import net.bibliavariasversiones.android.control.event.ABEventBus;
import net.bibliavariasversiones.android.control.event.EventManager;
import net.bibliavariasversiones.android.control.page.window.ActiveWindowPageManagerProvider;
import net.bibliavariasversiones.android.control.page.window.WindowControl;
import net.bibliavariasversiones.servicios.download.RepoFactory;
import net.bibliavariasversiones.servicios.font.FontControl;
import net.bibliavariasversiones.servicios.sword.SwordDocumentFacade;

import java.util.concurrent.Executors;

import dagger.Module;
import dagger.Provides;

/**
 * Dagger module to create application scoped dependencies
 *
 * @author Martin Denham [mjdenham at gmail dot com]
 */
@Module
public class ApplicationModule {

	@Provides
	@ApplicationScope
	public DownloadControl provideDownloadControl(SwordDocumentFacade swordDocumentFacade, RepoFactory repoFactory) {
		return new DownloadControl(new DownloadQueue(Executors.newSingleThreadExecutor(), repoFactory), repoFactory, FontControl.getInstance(), swordDocumentFacade);
	}

	@Provides
	@ApplicationScope
	public ActiveWindowPageManagerProvider provideActiveWindowPageManagerProvider(WindowControl windowControl) {
		return windowControl;
	}

	@Provides
	@ApplicationScope
	public ResourceProvider provideResourceProvider(AndroidResourceProvider androidResourceProvider) {
		return androidResourceProvider;
	}

	@Provides
	@ApplicationScope
	public EventManager eventManagerProvider() {
		return ABEventBus.getDefault();
	}

	@Provides
	@ApplicationScope
	public Emailer emailer(EmailerImpl emailerImpl) {
		return emailerImpl;
	}
}
