/*
 * Copyright (c) 2018 Martin Denham, Tuomas Airaksinen and the And Bible contributors.
 *
 * This file is part of And Bible (http://github.com/AndBible/and-bible).
 *
 * And Bible is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * And Bible is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with And Bible.
 * If not, see http://www.gnu.org/licenses/.
 *
 */

/**
 * 
 */
package net.bibliavariasversiones.android.control.mynote;

import android.util.Log;
import android.widget.Toast;

import net.bibliavariasversiones.android.BibleApplication;
import net.bibliavariasversiones.android.activity.R;
import net.bibliavariasversiones.android.control.ApplicationScope;
import net.bibliavariasversiones.android.control.page.CurrentPageManager;
import net.bibliavariasversiones.android.control.page.window.ActiveWindowPageManagerProvider;
import net.bibliavariasversiones.servicios.common.CommonUtils;
import net.bibliavariasversiones.servicios.db.mynote.MyNoteDto;

import org.crosswire.jsword.passage.Key;
import org.crosswire.jsword.passage.KeyUtil;
import org.crosswire.jsword.passage.Verse;
import org.crosswire.jsword.passage.VerseRange;
import org.crosswire.jsword.versification.Versification;

import java.util.List;

import javax.inject.Inject;

/**
 * User Note controller methods
 *
 * @author John D. Lewis [balinjdl at gmail dot com]
 * @author Martin Denham [mjdenham at gmail dot com]
 */
@ApplicationScope
public class MyNoteControl {

	private final ActiveWindowPageManagerProvider activeWindowPageManagerProvider;

	private static final String MYNOTE_SORT_ORDER = "MyNoteSortOrder";

	private final MyNoteDAO myNoteDAO;

	private static final String TAG = "MyNoteControl";

	@Inject
	public MyNoteControl(ActiveWindowPageManagerProvider activeWindowPageManagerProvider, MyNoteDAO myNoteDAO) {
		this.activeWindowPageManagerProvider = activeWindowPageManagerProvider;
		this.myNoteDAO = myNoteDAO;
	}

	/**
	 * Start chain of actions to switch to MyNote view
	 * @param verseRange
	 */
	public void showMyNote(VerseRange verseRange) {
		// if existing MyNote exists with same start verse then adjust range to match the note that will be edited
		final MyNoteDto existingMyNoteWithSameStartVerse = myNoteDAO.getMyNoteByStartVerse(verseRange);
		if (existingMyNoteWithSameStartVerse!=null) {
			verseRange = existingMyNoteWithSameStartVerse.getVerseRange(verseRange.getVersification());
		}

		getCurrentPageManager().showMyNote(verseRange);
	}

	public void showNoteView(MyNoteDto noteDto) {
		getCurrentPageManager().showMyNote(noteDto.getVerseRange());
	}

	public String getMyNoteVerseKey(MyNoteDto myNote) {
		String keyText = "";
		try {
			Versification versification = getCurrentPageManager().getCurrentBible().getVersification();
			keyText = myNote.getVerseRange(versification).getName();
		} catch (Exception e) {
			Log.e(TAG, "Error getting verse text", e);
		}
		return keyText;
	}

	public boolean saveMyNoteText(String myNote) {
		MyNoteDto dto = getCurrentMyNoteDto();
		dto.setNoteText(myNote);
		return saveMyNote(dto);
	}

	public MyNoteDto getCurrentMyNoteDto() {
		//
		Key key = getCurrentPageManager().getCurrentMyNotePage().getKey();
		VerseRange verseRange;
		// The key should be a VerseRange
		if (key instanceof VerseRange) {
			verseRange = (VerseRange)key;
		} else {
			Verse verse = KeyUtil.getVerse(key);
			verseRange = new VerseRange(verse.getVersification(), verse);
		}
		
		// get a dto
		MyNoteDto myNote = myNoteDAO.getMyNoteByStartVerse(verseRange);
		
		// return an empty note dto
		if (myNote==null) {
			myNote = new MyNoteDto();
			myNote.setVerseRange(verseRange);
		}

		return myNote;
	}

	/** save the note to the database if it is new or has been updated
	 */
	public boolean saveMyNote(MyNoteDto myNoteDto) {
		Log.d(TAG, "saveMyNote started...");
		boolean isSaved = false;
		
		if (myNoteDto.isNew()) {
			if (!myNoteDto.isEmpty()) {
				myNoteDAO.addMyNote(myNoteDto);
				isSaved = true;
			}
		} else {
			MyNoteDto oldNote = myNoteDAO.getMyNoteByStartVerse(myNoteDto.getVerseRange());
			// delete empty notes
			if (myNoteDto.isEmpty()) {
				myNoteDAO.deleteMyNote(myNoteDto);
			} else if (!myNoteDto.equals(oldNote)) {
				// update changed notes
				myNoteDAO.updateMyNote(myNoteDto);
				isSaved = true;
			}
		}
		if (isSaved) {
			Toast.makeText(BibleApplication.Companion.getApplication().getApplicationContext(), R.string.mynote_saved, Toast.LENGTH_SHORT).show();
		}
		return isSaved;
	}

	public String getMyNoteText(MyNoteDto myNote, boolean abbreviated) {
		String text = "";
		try {
			text = myNote.getNoteText();
			if (abbreviated) {
				//TODO allow longer lines if portrait or tablet
				boolean singleLine = true;
				text = CommonUtils.limitTextLength(text, 40, singleLine);
			}
		} catch (Exception e) {
			Log.e(TAG, "Error getting user note text", e);
		}
		return text;
	}

	// pure myNote methods

	/** get all myNotes */
	public List<MyNoteDto> getAllMyNotes() {

		return myNoteDAO.getAllMyNotes(getSortOrder());
	}

	/** delete this user note (and any links to labels) */
	public boolean deleteMyNote(MyNoteDto myNote) {
		return myNoteDAO.deleteMyNote(myNote);
	}

	public void changeSortOrder() {
		if (getSortOrder().equals(MyNoteSortOrder.BIBLE_BOOK)) {
			setSortOrder(MyNoteSortOrder.DATE_CREATED);
		} else {
			setSortOrder(MyNoteSortOrder.BIBLE_BOOK);
		}
	}
	
	public MyNoteSortOrder getSortOrder() {
		String sortOrderStr = CommonUtils.getSharedPreference(MYNOTE_SORT_ORDER, MyNoteSortOrder.BIBLE_BOOK.toString());
		return MyNoteSortOrder.valueOf(sortOrderStr);
	}
	
	private void setSortOrder(MyNoteSortOrder sortOrder) {
		CommonUtils.saveSharedPreference(MYNOTE_SORT_ORDER, sortOrder.toString());
	}

	public String getSortOrderDescription() {
		if (MyNoteSortOrder.BIBLE_BOOK.equals(getSortOrder())) {
			return CommonUtils.getResourceString(R.string.sort_by_bible_book);
		} else {
			return CommonUtils.getResourceString(R.string.sort_by_date);
		}
	}

	public CurrentPageManager getCurrentPageManager() {
		return activeWindowPageManagerProvider.getActiveWindowPageManager();
	}
}
