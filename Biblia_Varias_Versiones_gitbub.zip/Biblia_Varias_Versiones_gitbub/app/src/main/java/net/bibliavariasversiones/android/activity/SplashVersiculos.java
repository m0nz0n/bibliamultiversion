package net.bibliavariasversiones.android.activity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import android.content.Intent;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Por J.A.MONZON
 */
public class SplashVersiculos extends AppCompatActivity {
    private static final int WAIT_TIME = 5000;

    private InterstitialAd interstitial;
    private Timer waitTimer;
    private boolean interstitialCanceled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_versiculo);
		MobileAds.initialize(this, getString(R.string.admob_id_aplicacion));
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.interstitial_publicidad));
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Si el intersticial fue cancelado debido a un timeout o al envío de una aplicación en segundo plano,
                // No muestres la intersticial.
                if (!interstitialCanceled) {
                    waitTimer.cancel();
                    interstitial.show();
                }
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // La intersticial falló al cargar. Inicie la aplicación.
                startMainActivity();
            }
			@Override
			public void onAdClosed() {
				startMainActivity();
			}
        });
        interstitial.loadAd(new AdRequest.Builder().build());

        waitTimer = new Timer();
        waitTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                interstitialCanceled = true;
                SplashVersiculos.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // El intersticial no se cargó en un tiempo razonable. Deja de esperar a que el
                        // intersticial e inicie la aplicación.
                        startMainActivity();
                    }
                });
            }
        }, WAIT_TIME);
    }

    @Override
    public void onPause() {
        // Voltear la bandera intersticialCancelada para que cuando el usuario regrese no se quede atascado en el interior.
        // la actividad de la pantalla de bienvenida.
        waitTimer.cancel();
        interstitialCanceled = true;
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (interstitial.isLoaded()) {
            // La intersticial terminó de cargarse mientras la aplicación estaba en segundo plano. Depende de ti lo que
            // El comportamiento debe ser cuando regresen. En este ejemplo, mostramos el intersticial desde
            // Ya está listo.
            interstitial.show();
        } else if (interstitialCanceled) {
            // Hay dos maneras en que el usuario puede llegar hasta aquí:
            //
            // 1. Después de desestimar la intersticial
            // 2. Presionando la tecla home y regresando después de la carga intersticial terminada.
            //
            // En cualquier caso, es incómodo dejarlos en la actividad de la pantalla de inicio, así que sólo tienes que iniciar el comando
            // aplicación.


            startMainActivity();
        }
    }


    private void startMainActivity() {
		startActivity(new Intent(SplashVersiculos.this, VersiculoDeldia.class));
		finish();
    }
}

