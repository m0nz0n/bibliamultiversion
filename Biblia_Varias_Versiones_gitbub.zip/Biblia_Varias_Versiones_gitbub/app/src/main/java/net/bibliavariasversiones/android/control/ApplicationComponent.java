/*
 * Copyright (c) 2018 Martin Denham, Tuomas Airaksinen and the And Bible contributors.
 *
 * This file is part of And Bible (http://github.com/AndBible/and-bible).
 *
 * And Bible is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * And Bible is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with And Bible.
 * If not, see http://www.gnu.org/licenses/.
 *
 */

package net.bibliavariasversiones.android.control;

import net.bibliavariasversiones.android.control.backup.BackupControl;
import net.bibliavariasversiones.android.control.bookmark.BookmarkControl;
import net.bibliavariasversiones.android.control.comparetranslations.CompareTranslationsControl;
import net.bibliavariasversiones.android.control.document.DocumentControl;
import net.bibliavariasversiones.android.control.download.DownloadControl;
import net.bibliavariasversiones.android.control.footnoteandref.FootnoteAndRefControl;
import net.bibliavariasversiones.android.control.footnoteandref.NoteDetailCreator;
import net.bibliavariasversiones.android.control.link.LinkControl;
import net.bibliavariasversiones.android.control.mynote.MyNoteControl;
import net.bibliavariasversiones.android.control.navigation.DocumentBibleBooksFactory;
import net.bibliavariasversiones.android.control.navigation.NavigationControl;
import net.bibliavariasversiones.android.control.page.PageControl;
import net.bibliavariasversiones.android.control.page.PageTiltScrollControlFactory;
import net.bibliavariasversiones.android.control.page.window.ActiveWindowPageManagerProvider;
import net.bibliavariasversiones.android.control.page.window.WindowControl;
import net.bibliavariasversiones.android.control.readingplan.ReadingPlanControl;
import net.bibliavariasversiones.android.control.report.ErrorReportControl;
import net.bibliavariasversiones.android.control.search.SearchControl;
import net.bibliavariasversiones.android.control.speak.SpeakControl;
import net.bibliavariasversiones.android.control.versification.BibleTraverser;
import net.bibliavariasversiones.android.view.activity.navigation.biblebookactionbar.BibleBookActionBarManager;
import net.bibliavariasversiones.android.view.activity.navigation.biblebookactionbar.SortActionBarButton;
import net.bibliavariasversiones.android.view.activity.page.BibleKeyHandler;
import net.bibliavariasversiones.android.view.activity.page.screen.WindowMenuCommandHandler;
import net.bibliavariasversiones.android.view.activity.readingplan.actionbar.ReadingPlanActionBarManager;
import net.bibliavariasversiones.android.view.activity.search.searchresultsactionbar.ScriptureToggleActionBarButton;
import net.bibliavariasversiones.android.view.activity.search.searchresultsactionbar.SearchResultsActionBarManager;
import net.bibliavariasversiones.android.view.activity.speak.actionbarbuttons.SpeakActionBarButton;
import net.bibliavariasversiones.android.view.activity.speak.actionbarbuttons.SpeakStopActionBarButton;
import net.bibliavariasversiones.servicios.history.HistoryManager;
import net.bibliavariasversiones.servicios.history.HistoryTraversalFactory;
import net.bibliavariasversiones.servicios.sword.SwordContentFacade;
import net.bibliavariasversiones.servicios.sword.SwordDocumentFacade;

import dagger.Component;

/**
 * Dagger Component to expose application scoped dependencies.
 *
 * @author Martin Denham [mjdenham at gmail dot com]
 */
@ApplicationScope
@Component(modules=ApplicationModule.class)
public interface ApplicationComponent {

	//Exposed to sub-graphs.
	WarmUp warmUp();
	ErrorReportControl errorReportControl();

	SwordDocumentFacade swordDocumentFacade();
	SwordContentFacade swordContentFacade();
	BibleTraverser bibleTraverser();
	NavigationControl navigationControl();
	DocumentBibleBooksFactory documentBibleBooksFactory();
	WindowControl windowControl();
	ActiveWindowPageManagerProvider activeWindowPageManagerProvider();
	LinkControl linkControl();
	PageTiltScrollControlFactory pageTiltScrollControlFactory();
	HistoryManager historyManager();
	HistoryTraversalFactory historyTraversalFactory();
	BibleKeyHandler bibleKeyHandler();

	DocumentControl documentControl();
	BackupControl backupControl();
	BookmarkControl bookmarkControl();
	MyNoteControl myNoteControl();
	NoteDetailCreator noteDetailCreator();
	DownloadControl downloadControl();
	PageControl pageControl();
	ReadingPlanControl readingPlanControl();
	SearchControl searchControl();
	CompareTranslationsControl compareTranslationsControl();
	FootnoteAndRefControl footnoteAndRefControl();

	SpeakControl speakControl();

	SortActionBarButton sortActionBarButton();
	SpeakActionBarButton speakActionBarButton();
	SpeakStopActionBarButton speakStopActionBarButton();
	ScriptureToggleActionBarButton scriptureToggleActionBarButton();
	ReadingPlanActionBarManager readingPlanActionBarManager();
	SearchResultsActionBarManager searchResultsActionBarManager();
	BibleBookActionBarManager bibleBookActionBarManager();
	WindowMenuCommandHandler windowMenuCommandHandler();
}
